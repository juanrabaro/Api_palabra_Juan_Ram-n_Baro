package com.example.ApiPalabraJR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPalabraJrApplicationTests {

	@Test
	void contextLoads() {
	}

}
